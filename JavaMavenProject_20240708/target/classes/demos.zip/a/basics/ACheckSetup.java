package a.basics;

public class ACheckSetup {

	public static void main(String[] args) {
		
		System.out.println("Hello Java again");

	}

}
