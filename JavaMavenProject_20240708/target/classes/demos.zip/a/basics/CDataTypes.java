package a.basics;

public class CDataTypes {
	public static void main(String[] args) {
		String name = "Sachin Tendulkar";
		System.out.println(name);  // "Sachin Tendulkar"
		System.out.println(name.length());  // "Sachin Tendulkar"
		
		
		
		int age = 21;
		System.out.println(age); // 21 
		
		char ch = 49; 
		System.out.println(ch);
		
		char c = '1';
		System.out.println(c);
		
		byte i = 5;
		short s = 1000;
		int d = 25000;
		long l = 4565252L;
		
		float f = 3.14f;
		double r = 3.29;
		
		
		
				
	}
}
