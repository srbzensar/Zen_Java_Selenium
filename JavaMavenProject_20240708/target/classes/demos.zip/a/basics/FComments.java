package a.basics;

/*
Author:
date: 
the program is about ...
*/
public class FComments {

	public static void main(String[] args) {

//		Following line will print hello on the screen
		// comment
//		I write come comment  (ctrl+slash)
		System.out.println("hello");
		
	}
}
