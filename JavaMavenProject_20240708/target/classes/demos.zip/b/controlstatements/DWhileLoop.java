package b.controlstatements;

public class DWhileLoop 
{
public static void main(String[] args) 
{
//	int i=1;
//
//	while(i<=10)
//	{
//		System.out.print(i + " ");  
//		i++;
//	}
	
	
//	challenge
//	print numbers 9 to 0 using while loop
	  int i= 9;
      while (i>=0)
      {
          System.out.print(i + " ");   
          i--;
      }
	
	
}
	
	
}
