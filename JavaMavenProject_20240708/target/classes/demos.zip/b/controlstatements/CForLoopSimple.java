package b.controlstatements;

public class CForLoopSimple {

	public static void main(String[] args) {

//		for(initialization;condition;increament/decreament)
//		for(int i=1; i<=10; i++)
//		{
//			System.out.println(i);
//		}
		
//		challenge
//		1. print numbers 10 to 1
//		2. print numbers 0 to 9
		
//		for(int i=10; i>=1; i--)
//		{
//			System.out.print(i + " ");
//		}
		
		
//		for(int i=0; i<=9; i++)					// n = 9	(i<=n)
//		{
//			System.out.println(i);
//		}
		
		for(int i=0; i<10; i++)				  // n = 10		(i<n)
		{
			System.out.print(i + "\t"); // \n newline
		}
		
		
	}

}
