package b.controlstatements;

public class ADrivingLicenseIf {

	public static void main(String[] args) {
		int age= 58;
		
////		if condition
		if(age>=18)
		{
			System.out.println("Driving license issued");
		}
		
////		if else		
//		if(age>=18)
//		{
//			System.out.println("Driving license issued");
//		}
//		else
//			System.out.println("Need to wait");
//			System.out.println("thanks"); //not part of else
		

//		if(age>=18)
//		{
//			System.out.println("Driving license issued");
//		}
//		else
//		{
//			System.out.println("Need to wait");
//			System.out.println("min age should be 18");
//		}

//		example
//		int number = 50;
//		if (number%2==0)
//			System.out.println("number is even");
//		else
//			System.out.println("number is odd");
		
////		Ternary operator ?:
////		condition?true?false
//		String r;
//		r = (number%2==0)?"even number":"odd number";
//		System.out.println(r);
		
		
////		if else ladder
//		if(age>40)
//			System.out.println("Fitment cert needed");
//		else if(age>=18)  // 18 to 40
//		{
//			System.out.println("Driving license issued");
//		}
//		else
//		{
//			System.out.println("Need to wait");
//			System.out.println("min age should be 18");
//		}
		
		
//		if(age>=18)  
//		{
//			if(age>40)
//				System.out.println("Fitment cert needed");
//			else
//				System.out.println("Driving license issued");
//		}
//		else
//		{
//			System.out.println("Need to wait");
//			System.out.println("min age should be 18");
//		}
		
		
		

////		nested if
		 age=20;  
		 int weight=40;
//		 
//		 if(age>=18)
//		 {    
//	        if(weight>50){  
//	            System.out.println("You are eligible to donate blood");  
//	        }    
//	     }    
		
////		and condition (logical opeator)
//		 if(age>=18 && weight>50)
//		 {    
//			 System.out.println("You are eligible to donate blood");  
//         }    
//		 else
//			 System.out.println("You are NOT eligible to donate blood");

		 
////			or condition (logical opeator)
//		 if(age>=18 || weight>50)
//		 {    
//			 System.out.println("You are eligible to donate blood");  
//         }    
//		 else
//			 System.out.println("You are NOT eligible to donate blood");		 
		 
		
	}

}
