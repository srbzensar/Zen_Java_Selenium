package oop.packagesex.packx;

public class D {

	public static void display()
	{
		System.out.println("Static display from packx.classD");
	}
	
	
	public static void main(String[] args) {

		System.out.println("D");
		display();
		D.display();
		
	}

}
