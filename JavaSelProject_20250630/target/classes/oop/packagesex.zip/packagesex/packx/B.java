package oop.packagesex.packx;

import static oop.packagesex.packx.D.display;


public class B {

//	public static void display()
//	{
//		System.out.println("Static display: local ");
//	}
	
	public static void main(String[] args) {

//		D.display();
		display();
		
	}

}
