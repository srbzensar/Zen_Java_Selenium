package oop.packagesex.packo;

import oop.packagesex.packz.X;


//public class Y extends X {
//
//	public static void main(String[] args) {
//		
//		Y obj = new Y();
//		
//		System.out.println(obj.pu);  
////		System.out.println(obj.pr); error
//		System.out.println(obj.ch);
////		System.out.println(obj.d);
//	}
//
//}

public class Y {

	public static void main(String[] args) {
		
		X obj = new X();
		
		System.out.println(obj.pu);  
//		System.out.println(obj.pr); error
//		System.out.println(obj.ch);
//		System.out.println(obj.d);
	}

}
