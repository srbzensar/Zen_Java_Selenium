package oop.packagesex.packz;

public class X {

	public int pu = 5;
	private int pr = 10;
	protected int ch = 40;
	int d = 50;
	
	public static void main(String[] args) {
		X obj = new X();
//		System.out.println(obj.pu);
//		System.out.println(obj.pr);
//		System.out.println(obj.ch);
//		System.out.println(obj.d);
		
	}

}
