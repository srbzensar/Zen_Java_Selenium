package oop.packagesex.packy;

import static oop.packagesex.packx.D.display;
//import oop.packagesex.packx.D;
import oop.packagesex.packx.*;

public class B {

//	public static void display()
//	{
//		System.out.println("Static display: local ");
//	}
	
	public static void main(String[] args) {

		D.display();
		display();
		
	}

}
